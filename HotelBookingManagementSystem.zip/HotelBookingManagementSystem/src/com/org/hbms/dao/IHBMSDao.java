package com.org.hbms.dao;

import java.sql.SQLException;

import com.org.hbms.bean.HBMSBookingBean;
import com.org.hbms.bean.HBMSHotelBean;
import com.org.hbms.bean.HBMSRoomBean;
import com.org.hbms.bean.HBMSUserBean;
import com.org.hbms.exception.HBMSException;

public interface IHBMSDao{

	int registerUser(HBMSUserBean b) throws HBMSException;

	boolean validateUserLogin(String username, String password) throws HBMSException;

	StringBuilder getHotelDetails() throws HBMSException;

	HBMSUserBean getUserDetails(String username, String password) throws HBMSException;

	StringBuilder displayRooms(String hotel_id) throws HBMSException;

	boolean isValidHotelId(String hotel_id) throws HBMSException;

	void addHotelDetails(HBMSHotelBean hotel) throws HBMSException;

	void deleteHotel(String hotelId) throws HBMSException;

	void deleteHotelRooms(String hotelId) throws HBMSException;

	void addRoomDetails(HBMSRoomBean room) throws HBMSException;

	boolean isValidRoomId(String roomId) throws HBMSException;

	void deleteRoom(String roomId) throws HBMSException;

	float getRoomAmount(String roomId) throws HBMSException;

	String addBookingDetails(HBMSBookingBean booking) throws HBMSException;

}
