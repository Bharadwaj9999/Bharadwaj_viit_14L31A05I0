package com.org.hbms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import com.org.hbms.dao.IQueryMapper;
import com.org.hbms.util.DBConnection;
import com.org.hbms.bean.HBMSBookingBean;
import com.org.hbms.bean.HBMSHotelBean;
import com.org.hbms.bean.HBMSRoomBean;
import com.org.hbms.bean.HBMSUserBean;
import com.org.hbms.exception.HBMSException;

public class HBMSDaoImpl implements IHBMSDao{

	@Override
	public int registerUser(HBMSUserBean b) throws HBMSException{
			Connection conn=DBConnection.getInstance().getConnection();
			PreparedStatement s;
			try {
				s=conn.prepareStatement(IQueryMapper.userIdQuery);
				ResultSet re=s.executeQuery();
				re.next();
				int id=re.getInt(1);
				String userID=Integer.toString(id);
				s = conn.prepareStatement(IQueryMapper.userRegisterQuery);
				s.setString(1,userID);
				s.setString(2,b.getPassword());
				s.setString(3,b.getRole());
				s.setString(4,b.getUserName());
				s.setString(5,b.getMobileNo());
				s.setString(6,b.getPhone());
				s.setString(7,b.getAddress());
				s.setString(8,b.getEmail());
				int c=s.executeUpdate();
				return id;
			} catch (SQLException e) {
				throw new HBMSException("problem in connecting to database");
			}
	}

	@Override
	public boolean validateUserLogin(String username, String password) throws HBMSException{
		Connection conn=DBConnection.getInstance().getConnection();
		PreparedStatement s;
		try {
			s = conn.prepareStatement(IQueryMapper.userValidQuery);
			s.setString(1,username);
			s.setString(2,password);
			ResultSet r=s.executeQuery();
			if(r.next())
			{
				int count=r.getInt(1);
				System.out.println(count);
				if(count>0)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		} catch (SQLException e) {
			throw new HBMSException("problem in connecting to database");
		}
		
	}

	@Override
	public StringBuilder getHotelDetails() throws HBMSException {
		Connection conn=DBConnection.getInstance().getConnection();
		try {
			PreparedStatement s=conn.prepareStatement(IQueryMapper.hotelDetailsQuery);
			ResultSet st=s.executeQuery();
			StringBuilder details=new StringBuilder("");
			while(st.next())
			{
				details.append(st.getString(1)+" ");
				details.append(st.getString(2)+" ");
				details.append(st.getString(3)+" ");
				details.append(st.getString(4)+" ");
				details.append(st.getString(5)+" ");
				details.append(st.getInt(6)+" ");
				details.append(st.getString(7)+" ");
				details.append(st.getString(8)+" ");
				details.append(st.getString(9)+" ");
				details.append(st.getString(10)+" ");
				details.append(st.getString(11)+" ");
				details.append("\n");
			}
			return details;
		} 
		catch (SQLException e) {
			throw new HBMSException("problem in connecting to database");
		}
	}

	@Override
	public HBMSUserBean getUserDetails(String username, String password) throws HBMSException {
		Connection conn=DBConnection.getInstance().getConnection();
		HBMSUserBean user=null;
		try {
			PreparedStatement s=conn.prepareStatement(IQueryMapper.getRoleQuery);
			s.setString(1,username);
			s.setString(2,password);
			ResultSet rs=s.executeQuery();
			if(rs.next())
			{
				user=new HBMSUserBean();
				user.setUserId(rs.getString(1));
				user.setPassword(rs.getString(2));
				user.setRole(rs.getString(3));
				user.setUserName(rs.getString(4));
				user.setMobileNo(rs.getString(5));
				user.setPhone(rs.getString(6));
				user.setAddress(rs.getString(7));
				user.setEmail(rs.getString(8));
			}
			return user;
		} catch (SQLException e) {
			throw new HBMSException("problem in connecting to database");
		}
	}

	@Override
	public StringBuilder displayRooms(String hotelId) throws HBMSException {
		Connection conn=DBConnection.getInstance().getConnection();
		try {
			PreparedStatement s=conn.prepareStatement(IQueryMapper.displayRoomQuery);
			s.setString(1,hotelId);
			ResultSet st=s.executeQuery();
			StringBuilder details=new StringBuilder("");
			while(st.next())
			{
				details.append(st.getString(1)+" ");
				details.append(st.getString(2)+" ");
				details.append(st.getString(3)+" ");
				details.append(st.getString(4)+" ");
				details.append(st.getFloat(5)+" ");
				details.append(st.getString(6)+" ");
				details.append("\n");
			}
			return details;
		}
		catch(SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
	}

	@Override
	public boolean isValidHotelId(String hotel_id) throws HBMSException {
		Connection conn=DBConnection.getInstance().getConnection();
		try {
			PreparedStatement s=conn.prepareStatement(IQueryMapper.validHotelQuery);
			s.setString(1,hotel_id);
			ResultSet st=s.executeQuery();
			if(st.next())
			{
				int count=st.getInt(1);
				if(count>0)
				{
					return true;
				}
			}
			return false;
		}
		catch(SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
	}

	@Override
	public void addHotelDetails(HBMSHotelBean hotel) throws HBMSException {
		Connection conn=null;
		try {
			conn=DBConnection.getInstance().getConnection();
			PreparedStatement s;
			s = conn.prepareStatement(IQueryMapper.hotelAddQuery);
			s.setString(1,hotel.getHotelId());
			s.setString(2,hotel.getCity());
			s.setString(3,hotel.getHotelName());
			s.setString(4,hotel.getAddress());
			s.setString(5,hotel.getDescription());
			s.setString(6,hotel.getAvgRatePerNight());
			s.setString(7,hotel.getPhoneNo1());
			s.setString(8,hotel.getPhoneNo2());
			s.setString(9,hotel.getRating());
			s.setString(10,hotel.getEmail());
			s.setString(11,hotel.getFax());
			int c=s.executeUpdate();
		} 
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
		
	}

	@Override
	public void deleteHotel(String hotelId) throws HBMSException {
		try 
		{
			Connection conn=null;
			conn=DBConnection.getInstance().getConnection();
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.deleteHotelQuery);
			s.setString(1, hotelId);
			s.executeUpdate();
		} 
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
				
	}

	@Override
	public void deleteHotelRooms(String hotelId) throws HBMSException {
		try 
		{
			Connection conn=null;
			conn=DBConnection.getInstance().getConnection();
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.deleteHotelRoomQuery);
			s.setString(1, hotelId);
			s.executeUpdate();
		} 
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
		
	}

	@Override
	public void addRoomDetails(HBMSRoomBean room) throws HBMSException {
		try
		{
			Connection conn=null;
			conn=DBConnection.getInstance().getConnection();
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.addRoomDetailsQuery);
			try
			{
				s.setString(1, room.getHotelId());
				s.setString(2, room.getRoomId());
				s.setString(3,room.getRoomNo());
				s.setString(4, room.getRoomType());
				s.setFloat(5,room.getPerNightRate());
				s.setString(6,room.getAvailability());
				s.executeUpdate();
			}
			catch(SQLException e)
			{
				System.out.println(e.getMessage());
			}
		}
		catch(SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
	}

	@Override
	public boolean isValidRoomId(String roomId) throws HBMSException {
		Connection conn=DBConnection.getInstance().getConnection();
		try {
			PreparedStatement s=conn.prepareStatement(IQueryMapper.validRoomQuery);
			s.setString(1,roomId);
			ResultSet st=s.executeQuery();
			if(st.next())
			{
				int count=st.getInt(1);
				if(count>0)
				{
					return true;
				}
			}
			return false;
		}
		catch(SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
	}

	@Override
	public void deleteRoom(String roomId) throws HBMSException {
		try 
		{
			Connection conn=null;
			conn=DBConnection.getInstance().getConnection();
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.deleteRoomQuery);
			s.setString(1, roomId);
			s.executeUpdate();
		} 
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
	}

	@Override
	public float getRoomAmount(String roomId) throws HBMSException {
		try 
		{
			Connection conn=null;
			conn=DBConnection.getInstance().getConnection();
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.getRoomAmountQuery);
			s.setString(1, roomId);
			ResultSet re=s.executeQuery();
			re.next();
			return re.getFloat(1);
		} 
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
	}

	@Override
	public String addBookingDetails(HBMSBookingBean booking) throws HBMSException {
		String bookingID=null;
		try 
		{
			Connection conn=null;
			conn=DBConnection.getInstance().getConnection();
			PreparedStatement s;
			s=conn.prepareStatement(IQueryMapper.userIdQuery);
			ResultSet re=s.executeQuery();
			re.next();
			int id=re.getInt(1);
			bookingID=Integer.toString(id);
			try
			{
			s=conn.prepareStatement(IQueryMapper.addBookingDetailsQuery);
			s.setString(1, bookingID);
			s.setString(2, booking.getRoomId());
			s.setString(3, booking.getUserId());
			s.setDate(4, new Date(booking.getBokkedFrom().getTime()));
			s.setDate(5,new Date(booking.getBookedTo().getTime()));
			s.setInt(6, booking.getNoOfAdults());
			s.setInt(7,booking.getNoOfChildren());
			s.setFloat(8,booking.getAmount());
			s.executeUpdate();
			}
			catch(SQLException e)
			{
				System.out.println(e.getMessage());
			}
		} 
		catch (SQLException e)
		{
			throw new HBMSException("problem in connecting to database");
		}
		return bookingID;
	}

}
