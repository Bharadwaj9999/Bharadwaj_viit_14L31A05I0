package com.org.hbms.service;

import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.org.hbms.bean.HBMSBookingBean;
import com.org.hbms.bean.HBMSHotelBean;
import com.org.hbms.bean.HBMSRoomBean;
import com.org.hbms.bean.HBMSUserBean;
import com.org.hbms.dao.HBMSDaoImpl;
import com.org.hbms.dao.IHBMSDao;
import com.org.hbms.exception.HBMSException;

public class HBMSserviceImpl implements IHBMSservice{

	@Override
	public String registerUser(HBMSUserBean b) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.registerUser(b);		
	}

	@Override
	public boolean validateUserLogin(String username, String password) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.validateUserLogin(username,password);
	}

	@Override
	public StringBuilder getHotelDetails() throws HBMSException{
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.getHotelDetails();
	}

	@Override
	public HBMSUserBean getUserDetails(String username, String password) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.getUserDetails(username,password);
	}

	@Override
	public boolean isValidPassword(String rPassword) {
		int length=rPassword.length();
		if(length>7 && length<0)
		{
			return false;
		}
		return true;
	}

	@Override
	public StringBuilder displayRooms(String hotel_id) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.displayRooms(hotel_id);
	}

	@Override
	public boolean isValidHotelId(String hotel_id) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.isValidHotelId(hotel_id);
	}

	@Override
	public boolean validateAdminLogin(String username, String password) {
		if(username.equals("admin") && password.equals("admin"))
		{
			return true;
		}
		return false;
	}

	@Override
	public String addHotelDetails(HBMSHotelBean hotel) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.addHotelDetails(hotel);
	}

	@Override
	public void deleteHotel(String hotelId) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		d1.deleteHotel(hotelId);
	}

	@Override
	public void deleteHotelRooms(String hotelId) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		d1.deleteHotelRooms(hotelId);
	}

	@Override
	public String addRoomDetails(HBMSRoomBean room) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.addRoomDetails(room);
	}

	@Override
	public boolean isValidRoomId(String roomId) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.isValidRoomId(roomId);
	}

	@Override
	public void deleteRoom(String roomId) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		d1.deleteRoom(roomId);
		
	}

	@Override
	public float getRoomAmount(String roomId) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.getRoomAmount(roomId);
	}

	@Override
	public String addBookingDetails(HBMSBookingBean booking) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.addBookingDetails(booking);
	}

	@Override
	public StringBuilder getBookingOfHotel(String hotelId) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.getBookingOfHotel(hotelId);
	}

	@Override
	public StringBuilder getGuestList(String hotelId) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.getGuestList(hotelId);
	}
	@Override
	public boolean isValidUsername(String rUserName) {
		// TODO Auto-generated method stub
		int length=rUserName.length();
		if(length>19)
		{
			return false;
		}
		Pattern namePattern=Pattern.compile("[A-Z|a-z]{3}[A-Z|a-z]*");
		Matcher nameMatcher=namePattern.matcher(rUserName);
		return nameMatcher.matches();
	}
	@Override
	public boolean isValidMobileNo(String rMobileNo) {
		// TODO Auto-generated method stub
		Pattern mobilePattern=Pattern.compile("[1-9]{1}[0-9]{9}");
		Matcher mobileMatcher=mobilePattern.matcher(rMobileNo);
		return mobileMatcher.matches();
	}
	@Override
	public boolean isValidPhoneNo(String rPhone) {
		// TODO Auto-generated method stub
		Pattern phonePattern=Pattern.compile("[1-9]{1}[0-9]{9}");
		Matcher phoneMatcher=phonePattern.matcher(rPhone);
		return phoneMatcher.matches();
	}

	@Override
	public boolean isValidAddress(String rAddress) {
		// TODO Auto-generated method stub
		int length=rAddress.length();
		if(length>25 || length<0)
		{
			return false;
		}
		return true;
		
	}

	@Override
	public boolean isValidEmailId(String rEmail) {
		Pattern namePattern=Pattern.compile(".*@.*");
		Matcher nameMatcher=namePattern.matcher(rEmail);
		return nameMatcher.matches();
	}
	@Override
	public boolean isValidCity(String city) {
		int length=city.length();
		if(length>9)
		{
			return false;
		}
		Pattern citynamePattern=Pattern.compile("[A-Z][a-z]{4}[A-Z|a-z]*");
		Matcher citynameMatcher=citynamePattern.matcher(city);
		return citynameMatcher.matches();
		
	}

	@Override
	public boolean isValidHotelName(String hotelName) {
		int length=hotelName.length();
		if(length>19)
		{
			return false;
		}
		Pattern hotelnamePattern=Pattern.compile("[A-Z|a-z]{4}[A-Z|a-z]*");
		Matcher hotelnameMatcher=hotelnamePattern.matcher(hotelName);
		return hotelnameMatcher.matches();
		
	}

	@Override
	public boolean isValidHotelAddress(String address) {
		int length=address.length();
		if(length>25 || length<0)
		{
			return false;
		}
		return true;
	}

	@Override
	public boolean isValidHotelDescription(String description) {
		int length=description.length();
		if(length>50 || length<0)
		{
			return false;
		}
		return true;
	}

	@Override
	public boolean isValidAvgRate(String avgRatePerNight) {
		
		Pattern avgRatePattern=Pattern.compile("[0-9]{2,}");
		Matcher avgRateMatcher=avgRatePattern.matcher(avgRatePerNight);
		return avgRateMatcher.matches();
	}

	@Override
	public boolean isValidPhoneNo1(String phoneNo1) {
		Pattern phonePattern=Pattern.compile("[1-9]{1}[0-9]{9}");
		Matcher phoneMatcher=phonePattern.matcher(phoneNo1);
		return phoneMatcher.matches();
		
	}

	@Override
	public boolean isValidPhoneNo2(String phoneNo2) {
		Pattern phonePattern=Pattern.compile("[1-9]{1}[0-9]{9}");
		Matcher phoneMatcher=phonePattern.matcher(phoneNo2);
		return phoneMatcher.matches();
	}

	@Override
	public boolean isValidRating(String rating) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isValidEmail(String email) {
		Pattern emailPattern=Pattern.compile(".*@.*");
		Matcher emailMatcher=emailPattern.matcher(email);
		return emailMatcher.matches();
		
	}

	@Override
	public boolean isValidFaxNo(String fax) {
		Pattern faxPattern=Pattern.compile("[+1]{1}[0-9]{14}");
		Matcher faxMatcher=faxPattern.matcher(fax);
		return faxMatcher.matches();
	}

	@Override
	public void changeRoomStatus(String roomId) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		d1.changeRoomStatus(roomId);		
	}

	@Override
	public StringBuilder getBookingOfSpecifiesDate(String date) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.getBookingOfSpecifiesDate(date);
	}

	@Override
	public void checkAvaialbilityStatus() throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		d1.checkAvailabilityStatus();
	}
}
