package com.author.recharge.service;

import java.sql.SQLException;

public interface IRechargeService {
	StringBuilder displayPlans() throws SQLException;
	void addUserDetails(String name,long mobile,String status,String planName,int amount) throws SQLException;
	void retrieveUserDetails() throws SQLException;
	int retrieveAmount(String plan) throws SQLException;
}
