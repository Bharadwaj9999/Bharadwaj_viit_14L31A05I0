package com.author.recharge.service;

import java.sql.SQLException;

import com.author.recharge.dao.IRechargeDao;
import com.author.recharge.dao.RechargeDaoImpl;

public class RechargeServiceImpl implements IRechargeService{

	@Override
	public StringBuilder displayPlans() throws SQLException {
		IRechargeDao i=new RechargeDaoImpl();
		return i.displayPlans();
	}

	@Override
	public void addUserDetails(String name,long mobile,String status,String planName,int amount) throws SQLException {
		// TODO Auto-generated method stub
		IRechargeDao r=new RechargeDaoImpl();
		r.addUserDetails(name, mobile, status, planName, amount);
	}

	@Override
	public void retrieveUserDetails() throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int retrieveAmount(String plan) throws SQLException {
		IRechargeDao i=new RechargeDaoImpl();
		return i.retrieveAmount(plan);
	}

}
