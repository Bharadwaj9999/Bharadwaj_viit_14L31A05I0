package com.author.recharge.dao;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class RechargeDaoImpl implements IRechargeDao{

	@Override
	public StringBuilder displayPlans() throws SQLException {
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","trini9999");
		java.sql.Statement s=conn.createStatement();
		String s1="select * from plans";
		ResultSet r=s.executeQuery(s1);
		StringBuilder s2=new StringBuilder("");
		s2.append("plans      amount\n");
		while(r.next())
		{
			s2.append(r.getString(1)+"     "+r.getInt(2)+"\n");
		}		
		return s2;
	}

	@Override
	public void addUserDetails(String name,long mobile,String status,String planName,int amount) throws SQLException {
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","trini9999");
		String s1="insert into rechargeInfo values(?,?,?,?,?,?)";
		//String s2="create sequence rechID increment by 1 start with 100000";
		PreparedStatement s=conn.prepareStatement(s1);
		//s.executeUpdate();
		//s=conn.prepareStatement(s1);
		s.setInt(1, 100);
		s.setString(2,name);
		s.setLong(3, mobile);
		s.setString(4,status);
		s.setString(5,planName);
		s.setInt(6,amount);
		s.executeUpdate();
	}

	@Override
	public void retrieveUserDetails() throws SQLException {
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","trini9999");
	}

	@Override
	public int retrieveAmount(String plan) throws SQLException {
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","trini9999");
		String s1="select amount from plans where planDetails='"+plan+"'";
		java.sql.Statement s=conn.createStatement();
		//String s1="select * from plans";
		int amount=0;
		ResultSet r=s.executeQuery(s1);
		while(r.next())
		{
			amount=r.getInt(1);
		}
		//ResultSet r=s.executeQuery(s1);
		return amount;
	}
	
}
