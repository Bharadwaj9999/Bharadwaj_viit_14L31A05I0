package com.author.recharge.pi;

import java.sql.SQLException;
import java.util.Scanner;

import com.author.recharge.bean.RechargeBean;
import com.author.recharge.service.IRechargeService;
import com.author.recharge.service.RechargeServiceImpl;

public class RechargeMain {
	public static void main(String a[]) throws SQLException
	{
		RechargeBean b1=new RechargeBean();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter username");
		String name=sc.next();
		b1.setUserName(name);
		System.out.println("enter mobile number");
		long mobileNum=sc.nextLong();
		b1.setUserMobileNum(mobileNum);
		IRechargeService s1=new RechargeServiceImpl();
		System.out.println("enter plan from below ones");
		System.out.println(s1.displayPlans());
		String planName=sc.next();
		b1.setPlanName(planName);
		s1.retrieveAmount(planName);
		b1.setAmount(s1.retrieveAmount(planName));
		b1.setStatus("recharge sucessfull");
		//System.out.println(b1.getAmount());
		s1.addUserDetails(b1.getUserName(),b1.getUserMobileNum(),b1.getStatus(),b1.getPlanName(),b1.getAmount());
	}
}
