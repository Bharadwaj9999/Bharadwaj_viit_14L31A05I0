package com.author.recharge.exception;

public class RechargeException extends Exception{
	public RechargeException(String exceptionName)
	{
		
	}
}
