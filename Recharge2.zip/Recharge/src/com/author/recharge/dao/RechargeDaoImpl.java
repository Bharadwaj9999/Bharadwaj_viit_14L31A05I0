package com.author.recharge.dao;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.author.recharge.exception.RechargeException;

public class RechargeDaoImpl implements IRechargeDao{
	@Override
	public StringBuilder displayPlans() throws SQLException {
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl","trg1127","training1127");
		StringBuilder s2=new StringBuilder("");
		java.sql.Statement s=conn.createStatement();
		try{
			ResultSet r=s.executeQuery(IQueryMapper.selectPlans);
			if(r.next())
			{
				s2.append("plans      amount\n");
				s2.append(r.getString(1)+"     "+r.getInt(2)+"\n");
				while(r.next())
				{
					s2.append(r.getString(1)+"     "+r.getInt(2)+"\n");
				}
			}
			else
			{
				throw new RechargeException("please select valid plan");
			}
			return s2;
		}
		catch(RechargeException e)
		{
			s2.append(e.getMessage());
			return s2;
		}
	}

	@Override
	public int addUserDetails(String name,long mobile,String status,String planName,int amount) throws SQLException {
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl","trg1127","training1127");
		PreparedStatement s=conn.prepareStatement(IQueryMapper.insertQuery);
		java.sql.Statement sw=conn.createStatement();
		ResultSet r1=sw.executeQuery(IQueryMapper.seqQuery);
		int val=0;
		while(r1.next())
		{
			val=r1.getInt(1);
		}
		s.setInt(1,val);
		s.setString(2,name);
		s.setLong(3, mobile);
		s.setString(4,status);
		s.setString(5,planName);
		s.setInt(6,amount);
		s.executeUpdate();
		return val;
	}
	@Override
	public StringBuilder retrieveUserDetails(int rechId) throws SQLException {
		
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl","trg1127","training1127");
		PreparedStatement s=conn.prepareStatement(IQueryMapper.userDetailsQuery);
		StringBuilder s2=new StringBuilder("");
		s.setInt(1, rechId);
		ResultSet r=s.executeQuery();
			if(r.next())
			{
				s2.append("rech id"+r.getInt(1)+"\nname:"+r.getString(2)+"\nmobile:"+r.getLong(3)+"\nstatus:"+r.getString(4)
					+"\nplan name:"+r.getString(5)+"\namount:"+r.getInt(6));
			}
			return s2;
	}

	@Override
	public int retrieveAmount(String plan) throws SQLException {
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl","trg1127","training1127");
		PreparedStatement s=conn.prepareStatement(IQueryMapper.retrieveAmountQuery);
		s.setString(1,plan);
		int amount=0;
		ResultSet r=s.executeQuery();
		while(r.next())
		{
			amount=r.getInt(1);
		}
		return amount;
	}

	@Override
	public boolean validPlan(String planName) throws SQLException {
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl","trg1127","training1127");
		PreparedStatement s=conn.prepareStatement(IQueryMapper.validPlanQuery);
		s.setString(1,planName);
		ResultSet r=s.executeQuery();
		int count=0;
		while(r.next())
		{
			count=r.getInt(1);
		}
		if(count==0)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	@Override
	public boolean validRechId(int rechId) throws SQLException {
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl","trg1127","training1127");
		PreparedStatement s=conn.prepareStatement(IQueryMapper.validRechIdQuery);
		s.setInt(1, rechId);
		ResultSet r=s.executeQuery();
		int count=0;
		while(r.next())
		{
			count=r.getInt(1);
		}
		if(count==0)
		{
			return false;
		}
		else
		{
			return true;
		}
	}
}
