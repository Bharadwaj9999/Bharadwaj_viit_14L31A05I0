package com.author.recharge.pi;

import java.sql.SQLException;
import java.util.Scanner;

import com.author.recharge.bean.RechargeBean;
import com.author.recharge.exception.RechargeException;
import com.author.recharge.service.IRechargeService;
import com.author.recharge.service.RechargeServiceImpl;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class RechargeMain {
	static Logger logger=Logger.getRootLogger();
	public RechargeMain()
	{
		PropertyConfigurator.configure("resources//log4j.properties");
	}
	public static void main(String a[]) throws SQLException, RechargeException
	{
		RechargeBean b1=new RechargeBean();
		RechargeMain m1=new RechargeMain();
		IRechargeService s1=new RechargeServiceImpl();
		//RechargeServiceImpl imp=null;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter username");
		String name=sc.next();
		while (true)
		{
			if (s1.validateName(name))
			{
				break;
			} 
			else
			{
				System.err.println("name should start with Capital letter and should contain only alphabets(min length:6)");
				name= sc.next();
			}
		}
		b1.setUserName(name);
		System.out.println("enter mobile number");
		String mobileNum=sc.next();
		while (true)
		{
			if (s1.validateMobileNum(mobileNum))
			{
				logger.info("mobile number validates sucessfully");
				break;
			} 
			else
			{
				System.err.println("Please enter valid mobile number");
				mobileNum= sc.next();
			}
		}
		long mobilenum=Long.parseLong(mobileNum);
		b1.setUserMobileNum(mobilenum);
		System.out.println("enter plan from below ones");
		System.out.println(s1.displayPlans());
		String planName=sc.next();
		if(s1.validPlan(planName))
		{
			b1.setPlanName(planName);
			s1.retrieveAmount(planName);
			b1.setAmount(s1.retrieveAmount(planName));
			b1.setStatus("recharge sucessfull");
			System.out.print("recharge sucessfull with rechargeId:");
		}
		else
		{
			b1.setPlanName(planName);
			b1.setAmount(0);
			b1.setStatus("recharge unsucessful");
			System.out.print("recharge unsucessfull with rechargeId:");
		}
		int recId=s1.addUserDetails(b1);
		b1.setRecID(recId);
		System.out.println(b1.getRecID());
		int ch,rechId;
		do
		{
			System.out.println("please select a choice");
			System.out.println("1.do you want to get any recharge details??");
			System.out.println("2.exit");
			ch=sc.nextInt();
			if(ch==1)
			{
				System.out.println("please enter recharge id");
				rechId=sc.nextInt();
				if(s1.validRechId(rechId))
				{
					System.out.println(s1.retrieveUserDetails(rechId));
				}
				else
				{
					System.out.println("no details found");
				}
			}
		}while(ch==1);
	}
}
