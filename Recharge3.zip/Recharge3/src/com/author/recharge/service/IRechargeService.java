package com.author.recharge.service;

import java.sql.SQLException;

import com.author.recharge.bean.RechargeBean;
import com.author.recharge.exception.RechargeException;

public interface IRechargeService {
	StringBuilder displayPlans() throws SQLException, RechargeException;
	StringBuilder retrieveUserDetails(int rechId) throws SQLException, RechargeException;
	int retrieveAmount(String plan) throws SQLException, RechargeException;
	boolean validPlan(String planName) throws SQLException, RechargeException;
	boolean validRechId(int rechId) throws SQLException, RechargeException;
	boolean validateMobileNum(String mobileNum);
	boolean validateName(String name);
	int addUserDetails(RechargeBean b1) throws SQLException, RechargeException;
}
