package com.author.recharge.dao;

public interface IQueryMapper {
	public static final String insertQuery="insert into rechargeInfo values(?,?,?,?,?,?)";
	public static final String selectPlans="select * from plans";
	public static final String seqQuery="select rec_seq.nextval from dual";
	public static final String userDetailsQuery="select * from rechargeInfo where rechargeId=?";
	public static final String retrieveAmountQuery="select amount from plans where planName=?";
	public static final String validPlanQuery="select count(*) from plans where planName=?";
	public static final String validRechIdQuery="select count(*) from rechargeInfo where rechargeId=?";
}